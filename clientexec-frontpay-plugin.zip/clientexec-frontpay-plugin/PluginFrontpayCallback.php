<?php
require_once 'modules/admin/models/PluginCallback.php';
require_once 'modules/admin/models/StatusAliasGateway.php';
require_once 'modules/billing/models/class.gateway.plugin.php';
require_once 'modules/billing/models/Invoice_EventLog.php';
require_once 'modules/admin/models/Error_EventLog.php';

class PluginFrontpayCallback extends PluginCallback
{
    function processCallback()
    {



        $fp_merchant_id  = $this->settings->get('plugin_frontpay_Merchant ID');
        $fp_merchant_secret  = $this->settings->get('plugin_frontpay_Merchant Key');
        $orderID = $_GET['transaction_reference'];
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://portal.frontpay.pk/api/get-order-detail',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('transaction_reference' => $orderID, 'fp_merchant_id' => $fp_merchant_id, 'fp_merchant_secret' => $fp_merchant_secret),
        ));

        $result = curl_exec($curl);

        curl_close($curl);
        // Submit the GET request

        $response = json_decode($result, true);


        $detail = $response['detail'];
        $invoiceId = $_GET['transaction_reference'];

        if ($detail['transaction_status'] == "COMPLETE") {
        $cPlugin = new Plugin($invoiceId, "frontpay", $this->user); 
        $cPlugin->setTransactionID($invoiceId);
        $cPlugin->setAmount($detail['original_amount']);
        $cPlugin->setAction('charge');
        $cPlugin->PaymentAccepted($detail['original_amount'], "FrontPay payment was accepted.", $detail['transaction_reference']);
        header('Location: '.$detail['fp_param3']);
        exit;
        }else{
            header('Location: '.$detail['failure_url']);
            exit;
        }
       
    }
}
