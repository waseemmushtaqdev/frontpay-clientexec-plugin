<?php
require_once 'modules/admin/models/GatewayPlugin.php';
require_once 'modules/billing/models/class.gateway.plugin.php';

class PluginFrontpay extends GatewayPlugin
{
    function getVariables() 
    {
        $variables = array(
            lang('Plugin Name') =>  [
                'type' =>  'hidden',
                'description' => lang('How CE sees this plugin ( not to be confused with the Signup Name )'),
                'value' => 'Frontpay'
            ],
            lang('Merchant ID') =>  [
                'type' => 'text',
                'description' => lang('Your Frontpay Merchant ID'),
                'value' => ''
            ],
            lang('Merchant Key') =>  [
                'type' => 'text',
                'description' => lang('Your Frontpay Merchant Secret Key'),
                'value' => ''
            ],
            lang('Signup Name') =>  [
                'type'        => 'text',
                'description' => lang('Select the name to display in the signup process for this payment type. Example: FrontPay or Credit Card.'),
                'value'       => 'FrontPay'
            ],            
            lang('Test Mode?') => [
                'type' => 'yesno',
                'description' => lang('Select to enable test/sandbox mode'),
                'value' => '0'
            ]
           
        );
        return $variables;
    }

    function credit($params)
    {
    }

    function singlePayment($params)
    {

        $FrontPaytURL = 'https://portal.frontpay.pk/api/clientexec-payment';

        $callBackURL = $params['clientExecURL'] . '/plugins/gateways/frontpay/callback.php';
        if ($params['isSignup'] == 1) {
            if ($this->settings->get('Signup Completion URL') != '') {
                $returnURL = $this->settings->get('Signup Completion URL') . '?success=1';
                $returnURLCancel = $this->settings->get('Signup Completion URL');
            } else {
                $returnURL = $params['clientExecURL'] . '/order.php?step=complete&pass=1';
                $returnURLCancel = $params['clientExecURL'] . '/order.php?step=3';
            }
        } else {
            $returnURL = $params['invoiceviewURLSuccess'];
            $returnURLCancel = $params['invoiceviewURLCancel'];
        }
        $mode = 'no';
        if ($this->getVariable('Test Mode?') == '1') {
            $mode = 'yes';
        }
        $data = [
            'merchant_id' => $this->getVariable('Merchant ID'),
            'merchant_key' => $this->getVariable('Merchant Key'),
            'mode' => $mode,
            'return_url' => $returnURL,
            'cancel_url' => $returnURLCancel,
            'notify_url' => $callBackURL,
            'name_first' => $params["userFirstName"],
            'name_last' => $params["userLastName"],
            'email_address' => $params["userEmail"],
            
            // Item details
            'm_payment_id' => $params['invoiceNumber'],
            'amount' => sprintf("%01.2f", round($params['invoiceTotal'], 2)),
            'currency' => $params['currencytype'],
            'item_name' => 'Invoice #' . $params['invoiceNumber'],
           
        ];

        $pfOutput = '';
        foreach ($data as $key => $val) {
            if (!empty($val)) {
                $pfOutput .= $key . '=' . urlencode(trim($val)) . '&';
            }
        }
        $getString = substr($pfOutput, 0, -1);
        $passPhrase = $this->getVariable('Passphrase');
        if (isset($passPhrase) && $passPhrase != '') {
            $getString .= '&passphrase=' . urlencode(trim($passPhrase));
        }
        $data['signature'] = md5($getString);

        $htmlForm = '<form action="' . $FrontPaytURL . '" method="post" name="frmFrontPay">';
        foreach ($data as $name => $value) {
            $htmlForm .= '<input name="' . $name . '" type="hidden" value="' . $value . '" />' . "\n";
        }
        $htmlForm .= "<script language=\"JavaScript\">\n";
        $htmlForm .= "document.forms['frmFrontPay'].submit();\n";
        $htmlForm .= "</script>\n";
        $htmlForm .= "</form>\n";

        echo $htmlForm;
        die();
    }

    function autopayment($params)
    {
    }
}
